<div id="moc_apalooza_accelevents_purchase_tickets" class="popup moc_speakers non-active">
	<div class="popup_container">
		<div class="popup_content">
			<div class="popup_close moc_profile_close moc_close_session_modal">
				<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
					<path fill-rule="evenodd" clip-rule="evenodd" d="M20.0001 2.00011L2.00011 20.0001L0.939453 18.9395L18.9395 0.939453L20.0001 2.00011Z" fill="white"/>
					<path fill-rule="evenodd" clip-rule="evenodd" d="M18.9393 20.0001L0.93934 2.00011L2 0.939453L20 18.9395L18.9393 20.0001Z" fill="white"/>
				</svg>
			</div>
			<!-- Popup Content -->
			<div class="popup_content_box">
				<div style="height: 800px;"><script src="https://www.accelevents.com/e/js/embedScriptV2.js" serverUrl="https://www.accelevents.com" eventUrl="MOps-Apalooza-2024" widgetName="tickets" widgetFor="EVENT" isFrom="display" organizerURL="undefined" iframeId="accelevents_embed_script_95587f5d-b0e4-4f1b-87f5-8075dbb8bf72_checkout_popup" embedType="tickets" id="embed_script_95587f5d-b0e4-4f1b-87f5-8075dbb8bf72"></script></div></div>
		</div>
	</div>
</div>
