<div class="loader_bg moc_home_loader">
<div class="loader"></div>
</div>
<div class="popup moc_iframe_popup non-active moc_home_watch_video">
    <div class="popup_overlay"></div>
    <div class="popup_content iframe_video">
        <div class="popup_close moc_profile_close">
			<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
				<circle cx="16" cy="16" r="15.35" stroke="white" stroke-width="1.3"/>
				<path d="M11 11L16 16L11 21" stroke="white" stroke-width="1.3"/>
				<path d="M21 11L16 16L21 21" stroke="white" stroke-width="1.3"/>
			</svg>
        </div>
        <!-- Popup Video -->
        <div class="popup_video moc_popup_embeded_video"></div>
    </div>
</div>