<?php
/**
 * This is only route file.
 *
 * @link       https://www.cmsminds.com/
 * @since      1.0.0
 *
 * @package    Marketing_Ops_Core
 * @subpackage Marketing_Ops_Core/admin
 */
