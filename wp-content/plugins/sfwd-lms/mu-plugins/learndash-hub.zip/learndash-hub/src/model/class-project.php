<?php

namespace LearnDash\Hub\Model;

use LearnDash\Hub\Framework\Model;

/**
 * Class Project
 *
 * @package LearnDash\Hub\Model
 */
class Project extends Model {


}
